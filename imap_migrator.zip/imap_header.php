<header>
<div class="body">
    <h1 class="title"><a href="<?php echo $imapmig_secure_url; ?>">IMAP <span id="imapmig_title">Migrator</span></a>
    <span id="imapmig_version">version 0.6b</span></h1>
    <h5 id="imapmig_subtitle">IMAP and POP3 Email Transfer Tool</h5>
    <nav>
    <div id="top_nav">
        <a href="<?php echo $imapmig_secure_url; ?>">IMAP Migrator</a>
        <a href="about.php">About</a>
        <a href="faq.php">FAQ</a>
        <a href="contact.php">Contact</a>
    </div>
    </nav>
    <hr class="divider1"></hr>
</div>
</header>